﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Xps.Packaging;
using System.Windows.Xps;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace ConsoleApplication1
{
    public class MyWindow : Window
    {
        public const Int32 WM_USER = 0x0400;
        private ConcurrentQueue<Color> _mapCommandQueue;
        private HwndSource _source;

        Grid grid = null;
        Canvas canvas = null;
        Rectangle rect = null;
        TextBlock tb = null;

        public MyWindow()
        {
            this.Width = 300;
            this.Height = 400;

            grid = new Grid();
            canvas = new Canvas();
            this.Content = grid;

            grid.Children.Add(canvas);

            rect = new Rectangle();
            rect.Height = 100;
            rect.Width = 100;

            tb = new TextBlock();
            tb.FontSize = 10;

            canvas.Children.Add(tb);
            canvas.Children.Add(rect);
        }

        public ConcurrentQueue<Color> CommandQueue
        {
            get
            {
                return _mapCommandQueue;
            }

            set
            {
                _mapCommandQueue = value;
            }
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);

            _source = PresentationSource.FromVisual(this) as HwndSource;
            if (_source != null) _source.AddHook(WndProc);
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled) // 
        {
            // Handle messages...
            var result = IntPtr.Zero;

            if (WM_USER == msg)
                CheckForNewTasks();


            return result;
        }
        private void CheckForNewTasks()
        {
            Color newCommand;
            while (_mapCommandQueue.TryDequeue(out newCommand))
            {
                //Console.WriteLine("get message value : " + newCommand.ToString());
                tb.Text = "get message value : " + newCommand.ToString();

                rect.Fill = new SolidColorBrush(newCommand);
                //using (MemoryStream lMemoryStream = new MemoryStream())
                //{
                //    using (Package package = Package.Open(lMemoryStream, FileMode.Create))
                //    {
                //        XpsDocument doc = new XpsDocument(package);
                //        XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(doc);
                //        writer.Write(this);
                //        doc.Close();
                //        package.Close();
                //    }

                //    //var pdfXpsDoc = PdfSharp.Xps.XpsModel.XpsDocument.Open(lMemoryStream);
                //    //PdfSharp.Xps.XpsConverter.Convert(pdfXpsDoc, d.FileName, 0);
                //}
            }
        }
    }
}
