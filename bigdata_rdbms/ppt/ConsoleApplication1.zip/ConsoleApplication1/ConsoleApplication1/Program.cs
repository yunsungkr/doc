﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Interop;
using System.Windows.Media;

namespace ConsoleApplication1
{
    class Program
    {
        [DllImport("user32.dll")]
        public static extern IntPtr PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
        public const Int32 WM_USER = 0x0400;

        private static Thread _worker;
        private static MyWindow _wpfControl;
        private static ConcurrentQueue<Color> _commendQueue = new ConcurrentQueue<Color>();

        private static IntPtr _leftHandMapWindowHandle;
        private static IntPtr LeftHandMapWindowHandle
        {
            get
            {
                if (_leftHandMapWindowHandle == IntPtr.Zero)
                {
                    if (!_wpfControl.Dispatcher.CheckAccess())
                    {
                        _leftHandMapWindowHandle = (IntPtr)_wpfControl.Dispatcher.Invoke(
                          new Func<IntPtr>(() => new WindowInteropHelper(_wpfControl).Handle)
                        );
                    }
                    else
                    {
                        _leftHandMapWindowHandle = new WindowInteropHelper(_wpfControl).Handle;
                    }
                }
                return _leftHandMapWindowHandle;
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Start main thread.");
            Console.WriteLine("enter and key.");
            Console.ReadKey();

            _worker = new Thread(() =>
            {
                _wpfControl = new MyWindow()
                {
                    CommandQueue = _commendQueue,
                };

                _wpfControl.Show();
                System.Windows.Threading.Dispatcher.Run();
            });

            _worker.SetApartmentState(ApartmentState.STA);
            _worker.IsBackground = true;
            _worker.Name = "MyWindow";
            _worker.Start();
            Console.WriteLine("Start wpf thread");

            Thread.Sleep(3000);

            // 작업값을 저장한다.
            _commendQueue.Enqueue(Colors.Red);

            Console.WriteLine("Enqueue Colors.Red");

            // 작업지시만 전달한다.
            PostMessage(LeftHandMapWindowHandle, WM_USER, IntPtr.Zero, IntPtr.Zero);

            Console.WriteLine("Send message");
            Thread.Sleep(3000);

            // 작업값을 저장한다.
            _commendQueue.Enqueue(Colors.Green);

            Console.WriteLine("Enqueue Colors.Green");
            // 작업지시만 전달한다.
            PostMessage(LeftHandMapWindowHandle, WM_USER, IntPtr.Zero, IntPtr.Zero);

            Console.WriteLine("Send message");
            Thread.Sleep(3000);

            _commendQueue.Enqueue(Colors.Blue);
            Console.WriteLine("Enqueue Colors.Blue");

            PostMessage(LeftHandMapWindowHandle, WM_USER, IntPtr.Zero, IntPtr.Zero);

            Console.WriteLine("Send message");
            Thread.Sleep(3000);

            Console.WriteLine("end");
            Console.ReadKey();
        }
    }
}
